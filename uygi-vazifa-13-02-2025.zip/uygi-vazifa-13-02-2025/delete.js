const fs = require("fs");
const path = require("path");

const filePath = path.join(__dirname, "fileToRemove.txt");

if (!fs.existsSync(filePath)) {
  throw new Error("FS operation failed");
}

fs.unlinkSync(filePath);
