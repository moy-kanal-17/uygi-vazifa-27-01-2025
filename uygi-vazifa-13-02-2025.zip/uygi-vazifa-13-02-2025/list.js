const fs = require("fs");
const path = require("path");

const dirPath = path.join(__dirname, "files");

if (!fs.existsSync(dirPath)) {
  throw new Error("FS operation failed");
}

console.log(fs.readdirSync(dirPath));

