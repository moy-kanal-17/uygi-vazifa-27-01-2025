const fs = require("fs");
const path = require("path");

const filePath = path.join(__dirname, "fileToRead.txt");

if (!fs.existsSync(filePath)) {
  throw new Error("FS operation failed");
}

console.log(fs.readFileSync(filePath, "utf-8"));

