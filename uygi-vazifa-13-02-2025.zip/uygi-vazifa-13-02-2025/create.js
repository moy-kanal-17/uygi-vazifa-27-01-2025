const fs = require("fs");
const path = require("path");

const filePath = path.join(__dirname, "files", "fresh.txt");

if (fs.existsSync(filePath)) {
  throw new Error("FS operation failed");
}

fs.writeFileSync(filePath, "I am fresh and young");
