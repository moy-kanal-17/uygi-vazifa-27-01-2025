const fs = require("fs");
const path = require("path");

const source = path.join(__dirname, "files");
const destination = path.join(__dirname, "files_copy");

if (!fs.existsSync(source) || fs.existsSync(destination)) {
  throw new Error("FS operation failed");
}

fs.mkdirSync(destination);

fs.readdirSync(source).forEach((file) => {
  fs.copyFileSync(path.join(source, file), path.join(destination, file));
});
