const fs = require("fs");
const path = require("path");

const filePath = path.join(__dirname, "sonlar.txt");

if (!fs.existsSync(filePath)) {
  throw new Error("FS operation failed");
}

const numbers = fs.readFileSync(filePath, "utf-8").split("\n").map(Number);
console.log(numbers);
