const fs = require("fs");
const path = require("path");

const filePath = path.join(__dirname, "sonlar.txt");
const numbers = Array.from({ length: 100 }, () =>
  Math.floor(Math.random() * 100)
);

fs.writeFileSync(filePath, numbers.join("\n"));
