const fs = require("fs");
const path = require("path");

const oldPath = path.join(__dirname, "wrongFilename.txt");
const newPath = path.join(__dirname, "properFilename.md");

if (!fs.existsSync(oldPath) || fs.existsSync(newPath)) {
  throw new Error("FS operation failed");
}

fs.renameSync(oldPath, newPath);
