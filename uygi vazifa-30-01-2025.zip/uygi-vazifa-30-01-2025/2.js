function processLogs(logs) {
  let userStats = new Map();

  logs.forEach((log) => {
    let [userName, ip, duration] = log.split(" ");
    duration = parseInt(duration);

    if (!userStats.has(userName)) {
      userStats.set(userName, { totalDuration: 0, ipAddresses: new Set() });
    }

    let userData = userStats.get(userName);
    userData.totalDuration += duration;
    userData.ipAddresses.add(ip);
  });

  userStats.forEach((data, userName) => {
    console.log(
      `${userName} - Total Duration: ${data.totalDuration}, IPs: ${[
        ...data.ipAddresses,
      ]
        .sort()
        .join(", ")}`
    );
  });
}
let logs = [
  "Ali 192.168.1.1 30",
  "Ali 192.168.1.2 40",
  "Ali 192.168.1.1 20",
  "Vali 10.0.0.1 50",
  "Vali 10.0.0.2 10",
  "Vali 10.0.0.1 20",
];

processLogs(logs);
