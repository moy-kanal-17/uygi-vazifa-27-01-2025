class PhoneDirectory {
  constructor() {
    this.users = new Map();
  }

  addUser(name) {
    if (!this.users.has(name)) {
      this.users.set(name, new Map());
    }
  }

  addPhoneNumber(name, label, number) {
    if (this.users.has(name)) {
      this.users.get(name).set(label, number);
    } else {
      console.log(`${name} topilmadi!`);
    }
  }

  updatePhoneNumber(name, label, newNumber) {
    if (this.users.has(name) && this.users.get(name).has(label)) {
      this.users.get(name).set(label, newNumber);
    } else {
      console.log(`Bunday ${label} telefon raqami ${name} uchun mavjud emas!`);
    }
  }

  deletePhoneNumber(name, label) {
    if (this.users.has(name) && this.users.get(name).has(label)) {
      this.users.get(name).delete(label);
    } else {
      console.log(`Bunday ${label} telefon raqami ${name} uchun topilmadi!`);
    }
  }

  getUserNumbers(name) {
    if (this.users.has(name)) {
      console.log(`${name} ning telefon raqamlari:`);
      this.users.get(name).forEach((number, label) => {
        console.log(`${label}: ${number}`);
      });
    } else {
      console.log(`${name} topilmadi!`);
    }
  }
}
const directory = new PhoneDirectory();
directory.addUser("Ali");
directory.addPhoneNumber("Ali", "Ish", "+998901234567");
directory.addPhoneNumber("Ali", "Uy", "+998931234567");
directory.updatePhoneNumber("Ali", "Ish", "+998909876543");
directory.getUserNumbers("Ali");
directory.deletePhoneNumber("Ali", "Uy");
directory.getUserNumbers("Ali");

