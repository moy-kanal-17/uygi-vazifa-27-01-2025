function nimadur_asabim_yetmayapri_uje_2_soat_qilyaman(plate) {
  const regex =/^(?:01|02|03|04|05|06|07|08|09|10|20|25|30|40|50|60|70|75|80|85|90|95)[ -]?[A-Z]?[ -]?\d{2,3}[ -]?[A-Z]{2}$/i;
  let javobde =  regex.test(plate);
  return javobde
}
console.log(nimadur_asabim_yetmayapri_uje_2_soat_qilyaman("01 A 501 BH"));