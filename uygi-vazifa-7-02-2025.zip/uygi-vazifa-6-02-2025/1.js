let divs = document.querySelectorAll(".special");
let overallIndex = 1;
divs.forEach((div, index) => {
  let paragraphs = div.querySelectorAll("p");
  paragraphs.forEach((p, pIndex) => {
    p.textContent = `Div ${index + 1}, Paragraf ${pIndex + 1}: ${
      p.textContent
    }`;
    p.style.color = "green";
    overallIndex++;});
  });