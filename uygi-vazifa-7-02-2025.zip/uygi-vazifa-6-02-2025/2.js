document.querySelector("h1").textContent = "DOM bilan ishlash";
document.querySelector("p").textContent = "Bu matn JS orqali o‘zgartirildi!";
document.querySelector("img").src = "masalade.jpg";