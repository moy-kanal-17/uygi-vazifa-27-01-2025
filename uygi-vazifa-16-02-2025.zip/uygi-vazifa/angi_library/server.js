const express = require("express");
const path = require("path");
const app = express();
const PORT = 3000;
app.use(express.static("views"));
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "views", "index.html"));
});
const pages = [
  "adabiyotlar",
  "maqolalar",
  "dissertatsiyalar",
  "monografiyalar",
  "muassasalar",
  "mualliflar",
  "jurnallar",
];
pages.forEach((page) => {
  app.get(`/${page}`, (req, res) => {
    res.sendFile(path.join(__dirname, "views", `${page}.html`));
  });
});
app.listen(PORT, () => {
  console.log(`Server http://localhost:${PORT} da ishga tushdi`);
});
