function odamSoni(astanovka) {
  let rem = 0;
  for (let i = 0; i < astanovka.length; i++) {
    const [boardee, board] = astanovka[i];
    rem += boardee - board;
  }
return rem;}
console.log(
  odamSoni([
    [10, 0],
    [3, 5],
    [5, 8],]));