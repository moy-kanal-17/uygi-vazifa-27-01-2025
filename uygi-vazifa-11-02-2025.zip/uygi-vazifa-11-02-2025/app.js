class Avto {
  constructor(marka, model, year) {
    this.marka = marka;
    this.model = model;
    this.year = year;
  }
}

class YengilAvto extends Avto {
  constructor(marka, model, year) {
    super(marka, model, year);
  }
}

class YukAvto extends Avto {
  constructor(marka, model, year) {
    super(marka, model, year);
  }
}

class Garaj {
  constructor(joylarSoni) {
    this.avtolar = [];
    this.joylarSoni = joylarSoni;
  }

  joyla(noviyAvto) {
    if (noviyAvto instanceof Avto) {
      if (this.avtolar.length < this.joylarSoni) {
        this.avtolar.push(noviyAvto);
        console.log("Avto qo’shildi!");
      } else {
        console.log("Uzr joy to’ldi.");
      }
    } else {
      console.log("Faqar Avtolar qo’shish mumkin");
    }
  }
}

let garage = new Garaj(2);
garage.joyla(new YukAvto("Kamaz", "Kamaz77", 2000));
console.log(garage.avtolar); 
garage.joyla(new YengilAvto("GM", "Nexia", 2018));
console.log(garage.avtolar); 
