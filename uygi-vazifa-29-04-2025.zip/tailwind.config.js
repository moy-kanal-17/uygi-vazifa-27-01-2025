     module.exports = {
       theme: {
         extend: {
           colors: {
             'primary': '#ff0000',
             'secondary': '#00ff00',
           },
         },
       },
     }