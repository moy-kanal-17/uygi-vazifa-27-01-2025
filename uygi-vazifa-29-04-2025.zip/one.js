// const arr = ['1', '2', '3'];
// let element;
// for (let i = 0; i < arr.length; i++) {
//      element = arr[i];
// }

// console.log(Math.max(...arr),'max');
// console.log(Math.min(...arr),"min");

// const array = [1,2,3,4,5]
// for (let i = 0; i < array.length; i++) {
// //   const element = array[i];
//   for (let j = 0; j < i; j++) {
//     if(j==i){
//         console.log('*');
//     }
//     else{
//       console.log(' ',j);
//       break
//     }
//   }

//   console.log(`/n`,i);
  

// }


// let x = NaN

// const y  =  null 

// var z = y+ x

// console.log(z, typeof z); // NaN 'number'



// const str  = 'Hello' // ,o = 1
// const str2 =  '' // l , = 2
// const OneW = 'o';
// let lengthOW=0;

// for (let i = 0 ; i<str.length ; i++){
//     console.log(str[i]);
//     if (str[i]==OneW){

//         lengthOW++
//     }
//     // console.log(lengthOW);
    
// }
// console.log(lengthOW,"👨‍💻");


// const str  = 'Helo World' //Outpute: hhelllloo wwoorrlldd
// let arr=[]
// let OneW = 0


// for(let i = 0 ; i<str.length ; i++){

// arr.push(str[i])
// arr.push(str[i])
// // OneW++
// console.log(str[i]);

// }

// console.log(arr.toString());



// const str  = '7' //Outpute: hhelllloo wwoorrlldd
let arr=[0,1,1]
let OneW = 4 //--- number


for(let i = 0 ; i<=OneW ; i++){
    if(i!==0 && i !== 1){
    if(i== arr[i]+i-1){
        arr.push(i)
        console.log(i);
    }
    console.log("not",i,arr[i]+i-1);
}
    
}