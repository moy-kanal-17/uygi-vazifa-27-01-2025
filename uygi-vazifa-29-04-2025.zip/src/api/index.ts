import axios from 'axios';

const axiosInstance = axios.create({
  baseURL: import.meta.env.VITE_BASE_URL || 'http://185.191.141.200:6969/api',
})


axiosInstance.interceptors.request.use(
    (config) => {
        const access_token = localStorage.getItem('access_token');
        if (access_token && access_token !== "undefined") {
            config.headers['Authorization'] = `Bearer ${access_token}`;
        }
        return config;
    }
);

export default axiosInstance;