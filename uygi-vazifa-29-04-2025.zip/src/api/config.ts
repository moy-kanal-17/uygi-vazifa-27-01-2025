import axiosInstance from ".";
import { Notification } from "../helpers";
export function apiConfig() {
  async function getRequest(url: string, params: object = {}) {
    try {
      const res = await axiosInstance.get(url, { params });
      console.log('Response🔥 :',res?.data);
      
      return res;
    } catch (error) {
      console.log("Error in GET request:", error);
    }
  }
  async function postRequest(url: string, body: object = {}) {
    try {
      const res = await axiosInstance.post(url, body);
      console.log('Response 💀:',res.data);
      
      return res;
    } catch (error) {
      console.log("😎Error in POST request:", error);
    
      Notification("error", `Xatolik ${error}`, "Parol yoki Email Notog'ri!.");
    }
  }

  async function putRequest(url: string, body: object = {}) {
    try {
      console.log(body);
      
      const res = await axiosInstance.patch(url, body);
      console.log('Response 💀:',res.data);
      
      return res;
    } catch (error) {
      console.log("😎Error in PUT request:", error);
      Notification("error", `Xatolik ${error}`, "Server bilan bog'lanishda xatolik yuz berdi.");
    }
  }

  async function deleteRequest(url:string) {
    try {
      const res = await axiosInstance.delete(url)

      return res
    } catch (error) {
      console.log(error);
      
    }
    
  }

  return {
    getRequest,
    postRequest,
    putRequest,
    deleteRequest
  };
}
