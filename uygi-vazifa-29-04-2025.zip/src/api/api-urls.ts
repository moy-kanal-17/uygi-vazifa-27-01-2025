export class ApiUrls {
//ADMIN AUTH
  public static  AUTH:string = '/log-in';

  public static  REGISTRATION:string = '/log-in';


  public static  GROUPS:string = '/group';

  public static  STUDENTS:string = '/student';

  public static  TEACHERS:string = '/teacher';



  // public static  ADMIN_AUTH_LOGOUT:string = '/admin_auth/logOut';
}
// http://185.191.141.200:6969/api/admin-auth/log-in