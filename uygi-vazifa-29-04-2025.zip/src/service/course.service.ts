import { apiConfig } from '@api/config';
import type { Course } from '../types/course';

export const courseService = {
  getCourses: async (): Promise<Course[]> => {
    const res = await apiConfig().getRequest('/courses');
    return res?.data.courses;
  },

  createCourse: async (data: Course): Promise<Course> => {
    const res = await apiConfig().postRequest('/courses', data);
    return res?.data;
  },

  updateCourse: async (id: number, data: Course): Promise<Course> => {
    const res = await apiConfig().putRequest(`/courses/${id}`, data);
    return res?.data;
  },

  deleteCourse: async (id: number) => {

    const res= await apiConfig().deleteRequest(`/courses/${id}`);
    return res
  },
};
