import { apiConfig } from "@api/config";
import type { Student } from '../types/student';
import { ApiUrls } from "@api/api-urls";

export const studentService = {
  getStudents: async (): Promise<Student[]> => {
    const res = await apiConfig().getRequest(`${ApiUrls.STUDENTS}`);
    return res?.data;
  },

  createStudent: async (data: Student): Promise<Student> => {
    const res = await apiConfig().postRequest(`${ApiUrls.STUDENTS}`, data);
    return res?.data;
  },

  updateStudent: async (id: number, data: Student): Promise<Student> => {
    const res = await apiConfig().putRequest(`${ApiUrls.STUDENTS}/${id}`, data);
    return res?.data;
  },

  deleteStudent: async (id: number): Promise<void> => {
    await apiConfig().deleteRequest(`${ApiUrls.STUDENTS}/${id}`);
  },
};
