import { ApiUrls } from "@api/api-urls";
import { apiConfig } from "@api/config";
import { type SignIn, type SignUp } from "@types";
export const authService = {



  async signIn(model: SignIn, role: string) {
    const res = await apiConfig().postRequest(
      `/${role}-auth${ApiUrls.AUTH}`,
      model
    );
    try {
      document.cookie = `access_token = ${res?.data.access_token}; path=/; max-age=3600`;
      localStorage.setItem("token", `${res?.data.token}`);
    } catch (error) {
      console.log(error);
    }
    console.log("token👨‍💻:", res?.data.access_token);

    return res;
  },

  // async signUp(model:SignOut){}
  async signUp(model: SignUp, role: string) {
    const res = await apiConfig().postRequest(`/${role}`, model);
    try {
        document.cookie = `token=${res?.data.token}; path=/; max-age=3600`;
      localStorage.setItem("token", `${res?.data.access_token}`);
    } catch (error) {
      console.log(error);
    }
    console.log("token👨‍💻:", res?.data.access_token);
    return res;
  },
};
