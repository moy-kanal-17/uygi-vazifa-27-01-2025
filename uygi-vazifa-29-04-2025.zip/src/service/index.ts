export * from './auth.service.ts'
export * from './groups.service.ts'
export * from './course.service.ts'