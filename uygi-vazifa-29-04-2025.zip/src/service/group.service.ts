import { apiConfig } from "@api/config";
import type { Group } from "../types/group";

export const groupService = {
  getGroups: async (): Promise<Group[]> => {
    const res = await apiConfig().getRequest('/group');
    console.log(res,"res✅");
    
    return res?.data;
  },

  createGroup: async (data: Group): Promise<Group> => {
    const res = await apiConfig().postRequest('/group', data);
    return res?.data;
  },

  updateGroup: async (id: number, data: Group): Promise<Group> => {
    const res = await apiConfig().putRequest(`/group/${id}`, data);
    return res?.data;
  },

  deleteGroup: async (id: number): Promise<void> => {
    await apiConfig().deleteRequest(`/group/${id}`);
  },
};
