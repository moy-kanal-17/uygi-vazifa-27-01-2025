import { createBrowserRouter, createRoutesFromElements, Route, RouterProvider } from "react-router-dom"
import App from "../App"
import { AdminLayout, Curs, Dashboart, GroupLayout, LayoutProtect, SignIn, SignUp, StudentAdmin, StudentLayout, TeacherLayout } from "@pages"
import TeacherSpisoks from "../pages/teacher_layout/teacherSpisoks"
import LoginProtect from "../pages/protect_pages/login_protect"
import { Worker } from "../pages/workers/workers"


const Router = () => {
    const router = createBrowserRouter(
        createRoutesFromElements(
          <><Route path="/" element={<App />}>
            <Route index element={<SignIn />}></Route>
            <Route path='/login' element={<LayoutProtect><SignIn /></LayoutProtect>}></Route>
            <Route path='/signup' element={<SignUp />}></Route>



            {/*Admin layout */}

            <Route path="admin" element={<LoginProtect><AdminLayout /></LoginProtect>}>
            <Route path="groups" element={<GroupLayout />} />
            <Route path="students" element={<StudentAdmin />} />
            <Route path="teachers" element={<TeacherSpisoks />} />
            <Route path="courses" element={<Curs />} /> 


            </Route>

            <Route path="lid" element={<AdminLayout />}>
            <Route path="groups" element={<GroupLayout />} />
            </Route>

<Route path="/student" element={<StudentLayout />}>
  <Route index element={<Dashboart />} />
  <Route path="courses" element={<Curs />} /> 
</Route>

          <Route path="teacher" element={<TeacherLayout />}>

          
        
          <Route path="groups" element={<GroupLayout />}>
          </Route>

          </Route>
          
          </Route>
          <Route path="worker" element={<Worker/>}></Route>

          <Route path="*" element={<div><h1>404 Not Found</h1></div>}></Route>
          
          
          </>
          

        )
    )

    return <RouterProvider router={router} />
}

export default Router;