import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { groupService } from '@service';
import type { Group } from '../types/group';

export const useGroups = () =>
  useQuery({
    queryKey: ['groups'],
    queryFn: groupService.getGroups,
  });

export const useCreateGroup = () => {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (data: Group) => groupService.createGroup(data),
    onSuccess: () => {
      client.invalidateQueries({ queryKey: ['groups'] });
    },
  });
};

export const useUpdateGroup = () => {
  const client = useQueryClient();
  return useMutation({
    mutationFn: ({ id, data }: { id: number; data: Group }) =>
      groupService.updateGroup(id, data),
    onSuccess: () => {
      client.invalidateQueries({ queryKey: ['groups'] });
    },
  });
};

export const useDeleteGroup = () => {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (id: number) => groupService.deleteGroup(id),
    onSuccess: () => {
      client.invalidateQueries({ queryKey: ['groups'] });
    },
  });
};