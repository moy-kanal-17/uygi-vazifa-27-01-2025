import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import axios from 'axios';
import type { Student } from '../types/student';
import { userService } from '../service/users.service';


export const useStudents = () => {
  return useQuery({
    queryKey: ['students'],
    queryFn: async () => {
      const res = await userService.getStudents();
      return res?.data ?? [];
    },
  });}

export const useCreateStudent = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: Omit<Student, 'id' | 'role'>) => userService.postUser( data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['students'] }),
  });
};

export const useUpdateStudent = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, data }: { id: number; data: Partial<Student> }) =>
      axios.patch(`/api/student/${id}`, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['students'] }),
  });
};

export const useDeleteStudent = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: number) => axios.delete(`/api/student/${id}`),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['students'] }),
  });
};