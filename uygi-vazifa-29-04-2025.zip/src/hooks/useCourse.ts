import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { courseService } from '../service/course.service';
import type { Course } from '../types/course';


export const useCourses = () =>
  useQuery({
    queryKey: ['courses'],
    queryFn: courseService.getCourses,
  });

export const useCreateCourse = () => {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (data: Course) => courseService.createCourse(data),
    onSuccess: () => {
      client.invalidateQueries({ queryKey: ['courses'] });
    },
  });
};

export const useUpdateCourse = () => {
  const client = useQueryClient();
  return useMutation({
    mutationFn: ({ id, data }: { id: number; data: Course }) =>
      courseService.updateCourse(id, data),
    onSuccess: () => {
      client.invalidateQueries({ queryKey: ['courses'] });
    },
  });
};

export const useDeleteCourse = () => {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (id: number) => courseService.deleteCourse(id),
    onSuccess: () => {
      client.invalidateQueries({ queryKey: ['courses'] });
    },
  });
};