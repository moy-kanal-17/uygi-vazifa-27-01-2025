export interface Group {
    name: string;
    course_id: number;
    status: string;
    start_data: string;
    end_data: string;
}