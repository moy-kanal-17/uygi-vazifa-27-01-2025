export interface Group {
    id?: number,
    name: string,
    course_id: number,
    status: string,
    start_date: string,
    end_date: string
}