export interface SignIn {
    email: string;
    password: string;
}

export interface SignUp {
    first_name: string,
    last_name: string,
    phone:string,
    email: string;
    password_hash: string;
    gender:string,
    date_of_birth: string ,
    lidId : number,
    eventsId : number,
    groupsId : number
}