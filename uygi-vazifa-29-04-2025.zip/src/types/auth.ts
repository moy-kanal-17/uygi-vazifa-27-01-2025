export interface SignIn {
    email: string
    password: string
}