
import React, { useEffect, useState } from 'react';
import { Table, Button, Modal, Form, Input, Select, message } from 'antd';
import { userService } from '../../service/users.service';

const { Option } = Select;

const Student: React.FC = () => {
  const [users, setUsers] = useState([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [form] = Form.useForm();
  const [editingId, setEditingId] = useState<number | null>(null);

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      const res = await userService.getStudents();
      setUsers(res);
    } catch {
      message.error('❌ Foydalanuvchilarni olishda xatolik!');
    }
  };

  const openModal = (user: any = null) => {
    setEditingId(user?.id || null);
    if (user) {
      form.setFieldsValue({ ...user });
    } else {
      form.resetFields();
    }
    setModalOpen(true);
  };

  const handleSubmit = async () => {
    try {
      const values = await form.validateFields();

      if (editingId) {
        await userService.updateUser(editingId, values);
        message.success('✅ Foydalanuvchi yangilandi');
      } else {
        await userService.postUser(values);
        message.success('✅ Foydalanuvchi yaratildi');
      }

      setModalOpen(false);
      fetchUsers();
    } catch {
      message.error('❌ Saqlashda xatolik yuz berdi!');
    }
  };

  const handleDelete = async (id: number) => {
    Modal.confirm({
      title: 'Foydalanuvchini o‘chirmoqchimisiz?',
      okText: 'Ha',
      cancelText: 'Yo‘q',
      onOk: async () => {
        try {
          await userService.deleteUser(id);
          fetchUsers();
          message.success('✅ Foydalanuvchi o‘chirildi');
        } catch {
          message.error('❌ O‘chirishda xatolik!');
        }
      },
    });
  };

  const columns = [
    { title: 'ID', dataIndex: 'id', key: 'id', width: 60 },
    { title: 'Ism', dataIndex: 'first_name', key: 'name' },
    { title: 'Email', dataIndex: 'email', key: 'email' },
    { title: 'Rol', dataIndex: 'role', key: 'role' },
    {
      title: 'Amallar',
      key: 'actions',
      render: (_: any, record: any) => (
        <>
          <Button type="primary" size='small' onClick={() => openModal(record)}>✏️</Button>
          <br />
          <Button type="primary" size='small' danger onClick={() => handleDelete(record.id)}>🗑️</Button>
        </>
      ),
    },
  ];

  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-bold">👥 Foydalanuvchilar</h2>
        <Button type="primary" onClick={() => openModal()}>Yangi Foydalanuvchi</Button>
      </div>

      <Table dataSource={users} columns={columns} rowKey="id" bordered pagination={{ pageSize: 8 }} />

      <Modal
        title={editingId ? '✏️ Tahrirlash' : '➕ Yangi foydalanuvchi'}
        open={modalOpen}
        onCancel={() => setModalOpen(false)}
        onOk={handleSubmit}
        okText="Saqlash"
        cancelText="Bekor"
        width={500}
      >
        <Form form={form} layout="vertical">
          <Form.Item name="first_name" label="Ism" rules={[{ required: true }]}>
            <Input />
          </Form.Item>
          <Form.Item name="email" label="Email" rules={[{ required: true, type: 'email' }]}>
            <Input />
          </Form.Item>
          
          {/* <Form.Item name="role" label="Rol" rules={[{ required: true }]}>
            <Select placeholder="Rolni tanlang">
              <Option value="admin">Admin</Option>
              <Option value="teacher">Teacher</Option>
              <Option value="student">Student</Option>
              <Option value="lid">Lid</Option>
            </Select>
          </Form.Item> */}
        </Form>
      </Modal>
    </div>
  );
};

export default Student;
