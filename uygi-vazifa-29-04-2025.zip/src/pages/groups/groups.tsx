  import React, { useEffect, useState } from 'react';
  import { Table, Button, Modal, Form, Input, DatePicker, Select, message } from 'antd';
  import { groupService } from '../../service/group.service';
  import dayjs from 'dayjs';

  const { Option } = Select;

  const GroupPage: React.FC = () => {
    const [groups, setGroups] = useState([]);
    const [modalOpen, setModalOpen] = useState(false);
    const [form] = Form.useForm();
    const [editingId, setEditingId] = useState<number | null>(null);

    useEffect(() => {
      fetchGroups();
    }, []);

    const fetchGroups = async () => {
      try {
        const res = await groupService.getGroups();
        setGroups(res?.data || []);
      } catch {
        message.error('❌ Guruhlarni olishda xatolik!');
      }
    };

    const openModal = (group: any = null) => {
      setEditingId(group?.id || null);
      if (group) {
        form.setFieldsValue({
          ...group,
          start_date: dayjs(group.start_date),
          end_date: dayjs(group.end_date),
        });
      } else {
        form.resetFields();
      }
      setModalOpen(true);
    };

    const handleSubmit = async () => {
      try {
        const values = await form.validateFields();
        const payload = {
          ...values
        };
        if (editingId) {
          await groupService.updateGroup(editingId, payload);
          message.success('✅ Guruh yangilandi');
        } else {
          payload.course_id=Number(payload.course_id)
          await groupService.createGroup(payload);
          message.success('✅ Guruh yaratildi');
        }
        setModalOpen(false);
        fetchGroups();
      } catch {
        message.error('❌ Xatolik yuz berdi!');
      }
    };

    const handleDelete = async (id: number) => {
      Modal.confirm({
        title: 'Guruhni o‘chirmoqchimisiz?',
        okText: 'Ha',
        cancelText: 'Yo‘q',
        onOk: async () => {
          try {
            await groupService.deleteGroup(id);
            fetchGroups();
            message.success('✅ Guruh o‘chirildi');
          } catch {
            message.error('❌ O‘chirishda xatolik!');
          }
        },
      });
    };

    const columns = [
      { title: 'ID', dataIndex: 'id', key: 'id', width: 60 },
      { title: 'Nomi', dataIndex: 'name', key: 'name' },
      { title: 'Kurs ID', dataIndex: 'course_id', key: 'course_id' },
      { title: 'Boshlanish', dataIndex: 'start_date', key: 'start_date' },
      { title: 'Tugash', dataIndex: 'end_date', key: 'end_date' },
      { title: 'Status', dataIndex: 'status', key: 'status' },
      {
        title: 'Amallar',
        key: 'actions',
        render: (_: any, record: any) => (
          <>
            <Button type="link" onClick={() => openModal(record)}>✏️</Button>
            <Button type="link" danger onClick={() => handleDelete(record.id)}>🗑️</Button>
          </>
        ),
      },
    ];

    return (
      <div>
        <div className="text_and_button flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold">📘 Guruhlar</h2>
          <Button type="primary" className='m-4' onClick={() => openModal()}>Yangi Guruh</Button>
        </div>

        <Table dataSource={groups} columns={columns} rowKey="id" bordered pagination={{ pageSize: 5 }} />

        <Modal
          title={editingId ? '✏️ Tahrirlash' : '➕ Yangi guruh'}
          open={modalOpen}
          onCancel={() => setModalOpen(false)}
          onOk={handleSubmit}
          okText="Saqlash"
          cancelText="Bekor"
          width={600}
        >
          <Form form={form} layout="vertical">
            <Form.Item name="name" label="Nomi" rules={[{ required: true }]}>
              <Input />
            </Form.Item>
            <Form.Item name="course_id" label="Kurs ID" rules={[{ required: true }]}>
              <Input type="number" />
            </Form.Item>
            <Form.Item name="start_date" label="Boshlanish" rules={[{ required: true }]}>
              <DatePicker className="w-full" />
            </Form.Item>
            <Form.Item name="end_date" label="Tugash" rules={[{ required: true }]}>
              <DatePicker className="w-full" />
            </Form.Item>
            <Form.Item name="status" label="Status" rules={[{ required: true }]}>
              <Select placeholder="Holatni tanlang">
                <Option value="new">New</Option>
                <Option value="active">Active</Option>
                <Option value="finished">Finished</Option>
              </Select>
            </Form.Item>
          </Form>
        </Modal>
      </div>
    );
  };

  export default GroupPage;
