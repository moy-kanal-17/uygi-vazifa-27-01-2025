import React, { useState } from 'react';
import {
  Layout,
  Menu,
  Table,
  Avatar,
  Dropdown,
  Typography,
  message,
  Modal,
  Form,
  Input,
  Select,
  DatePicker,
  InputNumber,
  Button,
} from 'antd';
import {
  HomeOutlined,
  BookOutlined,
  UserOutlined,
  LogoutOutlined,
} from '@ant-design/icons';
import { useNavigate, useLocation, Outlet } from 'react-router-dom';
import dayjs from 'dayjs';
import { useCreateStudent, useDeleteStudent, useStudents, useUpdateStudent } from '../../hooks/useStudents';

const { Header, Sider, Content, Footer } = Layout;
const { Title } = Typography;
const { Option } = Select;

const StudentAdmin: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [collapsed, setCollapsed] = useState(false);
  const [modalOpen, setModalOpen] = useState(false);
  const [form] = Form.useForm();
  const [editingId, setEditingId] = useState<number | null>(null);

  const { data } = useStudents();
  const users = data?.students || [];

  const createStudent = useCreateStudent();
  const updateStudent = useUpdateStudent();
  const deleteStudent = useDeleteStudent();

  const menuItems = [
    { key: 'dashboard', icon: <HomeOutlined />, label: 'Дашборд', path: '/student' },
    { key: 'courses', icon: <BookOutlined />, label: 'Курсы', path: '/student/courses' },
    { key: 'profile', icon: <UserOutlined />, label: 'Профиль', path: '/student/profile' },
  ];

  const getSelectedKey = () => {
    const path = location.pathname;
    if (path === '/student') return 'dashboard';
    if (path.startsWith('/student/courses')) return 'courses';
    if (path.startsWith('/student/profile')) return 'profile';
    return 'dashboard';
  };

  const handleLogout = () => {
    localStorage.removeItem('access_token');
    localStorage.removeItem('role');
    navigate('/login');
    message.success('✅ Вы успешно вышли!');
  };

  const userMenu = (
    <Menu
      items={[
        {
          key: 'logout',
          icon: <LogoutOutlined />,
          label: <span onClick={handleLogout}>Выйти</span>,
        },
      ]}
    />
  );

  const openModal = (user: any | null = null) => {
    setEditingId(user?.id || null);
    if (user) {
      form.setFieldsValue({
        ...user,
        date_of_birth: user.date_of_birth ? dayjs(user.date_of_birth) : null,
        eventsId:null,
        groupsId:null,
        lidId:null 
      });
    } else {
      form.resetFields();
    }
    setModalOpen(true);
  };

  const handleSubmit = async () => {
    try {
      const values = await form.validateFields();
      const payload = {
        ...values,
        confirm_password:values.password_hash,
        date_of_birth: values.date_of_birth?.format('YYYY-MM-DD'),
        eventsId: null,
        groupsId: null,
        lidId:null,
      };

      if (editingId) {
        const { password_hash, ...updatePayload } = payload; // Исключаем password_hash при редактировании
        console.log('Update payload:', updatePayload);
        await updateStudent.mutateAsync({ id: editingId, data: updatePayload });
        message.success('✅ Студент обновлён');
      } else {
        console.log('Create payload:', payload);
        await createStudent.mutateAsync(payload);
        message.success('✅ Студент создан');
      }
      setModalOpen(false);
    } catch (err) {
      console.error('Error:', err);
      message.error('❌ Ошибка сохранения');
    }
  };
<h1>!!</h1>
  const handleDelete = async (id: number) => {
    Modal.confirm({
      title: 'Удалить студента?',
      onOk: async () => {
        try {
          await deleteStudent.mutateAsync(id);
          message.success('✅ Студент удалён');
        } catch {
          message.error('❌ Ошибка удаления');
        }
      },
    });
  };

  const columns = [
    { title: 'ID', dataIndex: 'id', key: 'id' },
    { title: 'Имя', dataIndex: 'first_name', key: 'first_name' },
    { title: 'Фамилия', dataIndex: 'last_name', key: 'last_name' },
    { title: 'Email', dataIndex: 'email', key: 'email' },
    { title: 'Роль', dataIndex: 'role', key: 'role' },
    {
      title: 'Действия',
      key: 'actions',
      render: (_: any, record: any) => (
        <div className="flex space-x-2">
          <Button type="link" onClick={() => openModal(record)} className="text-blue-500 hover:text-blue-700">
            ✏️
          </Button>
          <Button type="link" danger onClick={() => handleDelete(record.id)} className="text-red-500 hover:text-red-700">
            🗑️
          </Button>
        </div>
      ),
    },
  ];

  return (
    <Layout className="min-h-screen bg-gray-100">


      <Layout>
        <Header className="">
          <Dropdown overlay={userMenu}>
            <Avatar className="" icon={<UserOutlined />} />
          </Dropdown>
        </Header>

        <Content className="m-6 p-6 bg-white rounded-lg shadow-md">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-2xl font-bold text-gray-800">📋 Студенты</h2>
            <Button
              type="primary"
              onClick={() => openModal()}
              className="bg-blue-500 hover:bg-blue-600 transition-colors"
            >
              Новый студент
            </Button>
          </div>
          <Table
            dataSource={users}
            columns={columns}
            rowKey="id"
            className="rounded-lg overflow-hidden"
            pagination={{ pageSize: 10 }}
          />
          <Outlet />
        </Content>

        <Modal
          title={editingId ? 'Редактировать студента' : 'Новый студент'}
          open={modalOpen}
          onCancel={() => setModalOpen(false)}
          onOk={handleSubmit}
          okButtonProps={{ className: 'bg-blue-500 hover:bg-blue-600' }}
          cancelButtonProps={{ className: 'hover:bg-gray-100' }}
          className="rounded-lg animate-fade-in"
        >
          <Form form={form} layout="vertical" className="space-y-4">
            <Form.Item
              name="first_name"
              label="Имя"
              rules={[{ required: true, message: 'Пожалуйста, введите имя!' }]}
            >
              <Input className="rounded-md border-gray-300 focus:border-blue-500" />
            </Form.Item>
            <Form.Item
              name="last_name"
              label="Фамилия"
              rules={[{ required: true, message: 'Пожалуйста, введите фамилию!' }]}
            >
              <Input className="rounded-md border-gray-300 focus:border-blue-500" />
            </Form.Item>
            <Form.Item
              name="email"
              label="Email"
              rules={[{ required: true, type: 'email', message: 'Пожалуйста, введите корректный email!' }]}
            >
              <Input className="rounded-md border-gray-300 focus:border-blue-500" />
            </Form.Item>
            <Form.Item
              name="phone"
              label="Телефон"
              rules={[
                { required: true, message: 'Пожалуйста, введите телефон!' },
                { pattern: /^\+998\d{9}$/, message: 'Номер должен начинаться с +998 и содержать 9 цифр!' },
              ]}
            >
              <Input className="rounded-md border-gray-300 focus:border-blue-500" />
            </Form.Item>
            {!editingId && (
              <Form.Item
                name="password_hash"
                label="Пароль"
                rules={[
                  { required: true, message: 'Пожалуйста, введите пароль!' },
                  { min: 8, message: 'Пароль должен быть не менее 8 символов!' },
                  {
                    pattern: /^(?=.*[A-Z])(?=.*\d).{8,}$/,
                    message: 'Пароль должен содержать хотя бы одну заглавную букву и одну цифру!',
                  },
                ]}
              >
                <Input.Password className="rounded-md border-gray-300 focus:border-blue-500" />
              </Form.Item>
            )}
            <Form.Item
              name="gender"
              label="Пол"
              rules={[{ required: true, message: 'Пожалуйста, выберите пол!' }]}
            >
              <Select className="rounded-md">
                <Option value="male">Мужской</Option>
                <Option value="female">Женский</Option>
              </Select>
            </Form.Item>
            <Form.Item
              name="date_of_birth"
              label="Дата рождения"
              rules={[{ required: true, message: 'Пожалуйста, выберите дату рождения!' }]}
            >
              <DatePicker className="w-full rounded-md border-gray-300 focus:border-blue-500" />
            </Form.Item>
            <Form.Item
              name="lidId"
              label="ID Лида"
              rules={[{ required: true, message: 'Пожалуйста, введите ID лида!' }]}
            >
              <InputNumber className="w-full rounded-md border-gray-300 focus:border-blue-500" />
            </Form.Item>
            <Form.Item
              name="eventsId"
              label="ID событий (через запятую)"
              rules={[
                { required: true, message: 'Пожалуйста, введите ID событий!' },
                {
                  validator: (_, value) => {
                    if (!value) return Promise.reject('Пожалуйста, введите ID событий!');
                    const ids = value.split(',').map((id: string) => id.trim());
                    if (ids.some((id: string) => isNaN(Number(id)))) {
                      return Promise.reject('ID событий должны быть числами, разделёнными запятыми!');
                    }
                    return Promise.resolve();
                  },
                },
              ]}
            >
              <Input
                className="rounded-md border-gray-300 focus:border-blue-500"
                placeholder="Пример: 1,2,3"
              />
            </Form.Item>
            <Form.Item
              name="groupsId"
              label="ID групп (через запятую)"
              rules={[
                { required: true, message: 'Пожалуйста, введите ID групп!' },
                {
                  validator: (_, value) => {
                    if (!value) return Promise.reject('Пожалуйста, введите ID групп!');
                    const ids = value.split(',').map((id: string) => id.trim());
                    if (ids.some((id: string) => isNaN(Number(id)))) {
                      return Promise.reject('ID групп должны быть числами, разделёнными запятыми!');
                    }
                    return Promise.resolve();
                  },
                },
              ]}
            >
              <Input
                className="rounded-md border-gray-300 focus:border-blue-500"
                placeholder="Пример: 1,2,3"
              />
            </Form.Item>
          </Form>
        </Modal>

        <Footer className="text-center bg-gray-200 py-4">
          Панель Студента ©{new Date().getFullYear()}
        </Footer>
      </Layout>
    </Layout>
  );
};

export default StudentAdmin;