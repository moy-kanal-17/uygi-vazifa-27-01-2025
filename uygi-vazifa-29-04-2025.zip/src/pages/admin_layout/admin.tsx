import React, { useState } from 'react';
import {
  EditOutlined,
  MenuFoldOutlined,
  MenuUnfoldOutlined,
  UploadOutlined,
  UserOutlined,
} from '@ant-design/icons';
import { Button, Layout, Menu, theme } from 'antd';
import { Outlet, useNavigate } from 'react-router-dom';

const { Header, Sider, Content } = Layout;

const AdminLayout: React.FC = () => {
  const [collapsed, setCollapsed] = useState(false);
  const navigate = useNavigate();
  const {
    token: { colorBgContainer, borderRadiusLG },
  } = theme.useToken();

  const handleMenuClick = (e: any) => {
    if(e.key ==='1') navigate('/admin/')
    if (e.key === '2') navigate('/admin/groups');
    if (e.key === '3') navigate('/admin/students');
    if (e.key === '4') navigate('/admin/teachers');
    if (e.key === '5') navigate('/admin/courses');
  };

  return (
    <Layout style={{ minHeight: '500vh' ,color:'black'}}>
      <Sider trigger={null} collapsible collapsed={collapsed}>
        <img src="/public/vite.svg" alt="ll" />
        <h1 className='color-white'>Admin panel Beta</h1>
        <div className="h-16 text-white text-center text-xl font-bold flex items-center justify-center">
          {collapsed ? 'A' : 'Admin Panel'}
        </div>
        <Menu
          theme="dark"
          mode="inline"
          defaultSelectedKeys={['1']}
          onClick={handleMenuClick}
          items={[

                        {
              key: '1',
              icon: <h1 >Admini Paneli</h1>,
              label: 'Beta',
            },
            {
              key: '2',
              icon: <UserOutlined />,
              label: 'Guruhlar',
            },
            {
              key: '3',
              icon: <EditOutlined />,
              label: 'Talabalar',
            },
            {
              key: '4',
              icon: <UploadOutlined />,
              label: 'O‘qituvchilar',
            },
                        {
              key: '5',
              icon: <UploadOutlined />,
              label: 'Kurs',
            },
          ]}
        />
      </Sider>

      <Layout>
        <Header
          style={{
            padding: 0,
            background: colorBgContainer,
            display: 'flex',
            alignItems: 'center',
            paddingLeft: 16,
          }}
        >
          <Button
            type="text"
            icon={collapsed ? <MenuUnfoldOutlined /> : <MenuFoldOutlined />}
            onClick={() => setCollapsed(!collapsed)}
            style={{
              fontSize: '18px',
            }}
          />
        </Header>

        <Content
          style={{
            margin: 0,
            padding: 24,
            minHeight: 'calc(100vh - 64px)',
            background: colorBgContainer,
            borderRadius: borderRadiusLG,
          }}
        >
          <Outlet />
        </Content>
      </Layout>
    </Layout>
  );
};

export default AdminLayout;
