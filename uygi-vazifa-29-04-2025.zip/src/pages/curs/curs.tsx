import React, { useEffect, useState } from "react";
import { courseService } from "../../service/course.service"; 
import type { Course } from "../../types/course"; 
import { Button, Table, message } from "antd";
import { Notification } from "../../helpers";

const Curs: React.FC = () => {
  const [courses, setCourses] = useState<Course[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

      const deleteCourses= async(id:number)=>{
      console.log('deleteCourses',id);
      const res = await courseService.deleteCourse(id)
      Notification(`info`,'success full!',`${res?.data.data.status}`)
      
    }

  useEffect(() => {
    const fetchCourses = async () => {
      try {
        const res = await courseService.getCourses();
        console.log("📚 Kurslar1:", res);
        setCourses(res);
      } catch (err) {
        message.error("❌ Kurslar yuklanmadi!");
      } finally {
        setLoading(false);
      }
    };


    fetchCourses();
  }, []);

  const columns = [
    { title: "ID", dataIndex: "id", key: "id" },
    { title: "title", dataIndex: "title", key: "title" },
    { title: "Tavsif", dataIndex: "description", key: "description" },
     {
      title: 'Действия',
      key: 'actions',
      render: (_: any, record: any) => (
        <div className="flex space-x-2">
          <Button type="link" onClick={() => console.log('editingId oynasi!')      /*openModal(record)*/} className="text-blue-500 hover:text-blue-700">
            ✏️
          </Button>
          <Button type="link" danger onClick={() => deleteCourses(record.id)} className="text-red-500 hover:text-red-700">
            🗑️
          </Button>
        </div>
      ),
    },
  ];

  return (
    <div style={{ padding: 24 }}>
      <h1 style={{ fontSize: 24, marginBottom: 16 }}>📚 Kurslar ro‘yxati</h1>
      <Table
        dataSource={courses}
        columns={columns}
        loading={loading}
        rowKey="id"
        bordered
      />
    </div>
  );
};
export default Curs; 