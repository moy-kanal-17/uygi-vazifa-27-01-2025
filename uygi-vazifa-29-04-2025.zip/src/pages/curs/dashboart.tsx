export const Dashboart: React.FC = () => {
    console.log('Dashbaort!');
    

    return(
        <div>

        <h1>Hello! Studetns Panel Beta</h1>
        
        </div>
    )
}

export default Dashboart