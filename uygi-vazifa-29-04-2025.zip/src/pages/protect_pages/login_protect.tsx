import React, { useState, type ReactNode } from "react";
import { getItem } from "../../helpers/storage";
import { Navigate } from "react-router-dom";


const LoginProtect = ({children}:{children:ReactNode})=>{

    const IsAuthted = getItem('access_token')
    if(!IsAuthted){ 
           return <Navigate to='/' replace />
    }


    return (
        <>
        {children}
        </>
    )
};

export default LoginProtect;