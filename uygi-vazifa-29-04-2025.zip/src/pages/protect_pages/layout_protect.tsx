import React, { type ReactNode } from "react";
import { getItem } from "../../helpers/storage";
import { Navigate } from "react-router-dom";
import { Notification } from "../../helpers";


const LayoutProtect=({children}:{children:ReactNode})=>{
    console.log("bu ishladi! mana token:");

const IsAuthted = getItem('access_token')
    console.log("bu ishladi! mana token:",IsAuthted);
    

 if (IsAuthted){
        const role = getItem('role')
        Notification('info','You logined!',`YOu  LOGGINED! you are ${role}!`)
        if(role){
           return <Navigate to={`/${role}`} replace />
        }
    }

    return (
        <>
    {children}
    </>
    )

}


export default LayoutProtect