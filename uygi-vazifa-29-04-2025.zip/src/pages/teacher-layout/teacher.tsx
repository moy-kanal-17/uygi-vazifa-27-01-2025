
const Teacher = () => {
  return (
    <div>
      <h1>Teacher</h1>
    </div>
  )
}

export default Teacher
