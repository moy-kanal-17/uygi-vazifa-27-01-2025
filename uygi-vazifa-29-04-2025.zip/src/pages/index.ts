import { lazy } from "react";
import { Worker } from "./workers/workers.tsx";

const SignIn = lazy(() => import("./auth/signIn.tsx"));
const SignUp = lazy(() => import("./auth/SignUp.tsx"));
const TeacherLayout = lazy(() => import("./teacher_layout/teacher.tsx"));
const AdminLayout = lazy(() => import("./admin_layout/admin.tsx"));
const StudentLayout = lazy(() => import("./student_layout/student.tsx"));
const StudentAdmin = lazy(() => import("./student_layout/studentSpisoks.tsx"));
const  Curs = lazy(() => import("./curs/curs.tsx"));

const GroupLayout = lazy(() => import("./groups/groups.tsx"));
const LoginProtect = lazy(()=> import('./protect_pages/login_protect.tsx'))
const LayoutProtect = lazy(()=> import('./protect_pages/layout_protect.tsx'))

const Dashboart = lazy(()=> import('./curs/dashboart.tsx'))

export {SignIn, SignUp,Curs,TeacherLayout, AdminLayout,StudentAdmin,Dashboart, StudentLayout,GroupLayout,LayoutProtect,LoginProtect};