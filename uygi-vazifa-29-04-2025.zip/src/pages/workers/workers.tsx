
import { Button } from 'antd'
import { useWorker } from '../../hooks'
import React from 'react'

export const Worker =()=>{
    const {runWorker,result} = useWorker()
    const calculate=()=>{
        runWorker(10000999990)
    }
    const test=()=>{
        console.log('test');
        
    }



return (
    <div>
        <Button type='primary' onClick={calculate}>calculate</Button>
        <Button type='primary' onClick={test}>test</Button>

    </div>
)
}