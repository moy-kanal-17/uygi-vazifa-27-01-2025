import React, { useCallback } from 'react';
import { Formik } from 'formik';
import * as Yup from 'yup';
import { Form, Input, Button, Select, Card, Typography, message } from 'antd';
import { useNavigate } from 'react-router-dom';
import { authService } from '@service';
import { setItem } from '../../helpers/storage';
import { Notification } from '../../helpers';

const { Option } = Select;
const { Title, Text } = Typography;

const SignInSchema = Yup.object().shape({
  email: Yup.string().email('Email noto‘g‘ri').required('Email majburiy'),
  password: Yup.string().min(6, 'Parol kamida 6 ta belgidan iborat').required('Parol majburiy'),
  role: Yup.string().required('Rol tanlanishi kerak'),
});

const SignIn: React.FC = () => {
  const navigate = useNavigate();

  const handleSubmit = useCallback(
    async (
      values: { email: string; password: string; role: string },
      { setSubmitting }: { setSubmitting: (isSubmitting: boolean) => void }
    ) => {
      try {
        const { email, password, role } = values;
        const payload = { email, password };
        const res = await authService.signIn({ email, password }, role);

        if (res?.status !== 201) throw new Error(res?.data?.message || 'Login xatoligi');

        setItem('access_token', res?.data?.access_token);
        setItem('role', role);
        Notification('success', 'Tizimga kirish muvaffaqiyatli!', 'Siz tizimga muvaffaqiyatli kirdingiz.');
        navigate(`/${role}`);
      } catch (err: any) {
        message.error(err?.response?.data?.message || 'Login xatoligi');
      } finally {
        setSubmitting(false);
      }
    },
    [navigate]
  );

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-indigo-700 via-purple-600 to-pink-500 p-4">
      <Card
        className="w-full max-w-md shadow-2xl rounded-3xl overflow-hidden transform transition-all hover:scale-105 animate-slide-up"
        bordered={false}
        style={{ background: 'linear-gradient(145deg, rgba(255,255,255,0.95), rgba(240,248,255,0.85))', backdropFilter: 'blur(10px)' }}
      >
        <div className="mb-8 text-center">
          <Title level={3} className="text-indigo-700 font-extrabold tracking-tight">
            Tizimga Kirish
          </Title>
          <Text className="text-gray-600">Iltimos, tizimga kirish uchun ma'lumotlarni kiriting.</Text>
        </div>

        <Formik
          initialValues={{ email: '', password: '', role: '' }}
          validationSchema={SignInSchema}
          onSubmit={handleSubmit}
        >
          {({ handleSubmit, handleChange, handleBlur, values, errors, touched, isSubmitting, setFieldValue }) => (
            <Form layout="vertical" onFinish={handleSubmit} className="space-y-6 px-4">
              <Form.Item
                label={<span className="text-gray-700 font-semibold">Email</span>}
                validateStatus={touched.email && errors.email ? 'error' : ''}
                help={touched.email && errors.email ? <span className="text-red-500 text-sm">{errors.email}</span> : null}
                className="animate-fade-in delay-100"
              >
                <Input
                  name="email"
                  placeholder="example@mail.com"
                  value={values.email}
                  onChange={handleChange}
                  onBlur={handleBlur}
                  className="rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 transition-all duration-300 hover:shadow-md"
                />
              </Form.Item>

              <Form.Item
                label={<span className="text-gray-700 font-semibold">Parol</span>}
                validateStatus={touched.password && errors.password ? 'error' : ''}
                help={touched.password && errors.password ? <span className="text-red-500 text-sm">{errors.password}</span> : null}
                className="animate-fade-in delay-200"
              >
                <Input.Password
                  name="password"
                  placeholder="********"
                  value={values.password}
                  onChange={handleChange}
                  onBlur={handleBlur}
                  className="rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 transition-all duration-300 hover:shadow-md"
                />
              </Form.Item>

              <Form.Item
                label={<span className="text-gray-700 font-semibold">Rolni tanlang</span>}
                validateStatus={touched.role && errors.role ? 'error' : ''}
                help={touched.role && errors.role ? <span className="text-red-500 text-sm">{errors.role}</span> : null}
                className="animate-fade-in delay-300"
              >
                <Select
                  placeholder="Rol tanlang"
                  value={values.role}
                  onChange={(value) => setFieldValue('role', value)}
                  onBlur={handleBlur}
                  className="rounded-lg"
                >
                  <Option value="teacher">O‘qituvchi</Option>
                  <Option value="student">Talaba</Option>
                  <Option value="admin">Admin</Option>
                  <Option value="lid">Lid</Option>
                </Select>
              </Form.Item>

              <Button
                type="primary"
                htmlType="submit"
                loading={isSubmitting}
                block
                className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white font-semibold rounded-lg transition-all duration-300 transform hover:scale-105 hover:shadow-lg animate-pulse-slow"
              >
                Kirish
              </Button>
            </Form>
          )}
        </Formik>
      </Card>
    </div>
  );
};

export default SignIn;
