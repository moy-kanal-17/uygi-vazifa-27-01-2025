import React, { useCallback, useMemo, useState } from 'react';
import { Formik, type FormikHelpers } from 'formik';
import * as Yup from 'yup';
import { useNavigate } from 'react-router-dom';
import { setItem } from '../../helpers/storage';
import { Notification } from '../../helpers';
import { authService } from '@service';

const getSchemaByRole = (role: string) => {
  switch (role) {
    case 'lid':
      return Yup.object().shape({
        first_name: Yup.string().required(),
        last_name: Yup.string().required(),
        target: Yup.string().required(),
        email: Yup.string().email().required(),
        password: Yup.string().min(6).required(),
        confirm_password: Yup.string().oneOf([Yup.ref('password')], 'Parollar mos emas').required(),
      });
    case 'student':
      return Yup.object().shape({
        first_name: Yup.string().required(),
        last_name: Yup.string().required(),
        phone: Yup.string().required(),
        email: Yup.string().email().required(),
        password: Yup.string().required(),
        gender: Yup.string().required(),
        date_of_birth: Yup.string().required(),
        lidId: Yup.number().required(),
        eventsId: Yup.number().required(),
        groupsId: Yup.number().required(),
      });
    case 'teacher':
    case 'admin':
      return Yup.object().shape({
        first_name: Yup.string().required(),
        last_name: Yup.string().required(),
        email: Yup.string().email().required(),
        password: Yup.string().min(6).required(),
      });
    default:
      return Yup.object();
  }
};

const SignUp: React.FC = () => {
  const navigate = useNavigate();
  const [role, setRole] = useState('');
  const validationSchema = useMemo(() => getSchemaByRole(role), [role]);

  const handleSubmit = useCallback(
    async (values: any, { setSubmitting }: FormikHelpers<any>) => {
      try {
        let payload: any = {};
        if (role === 'lid') {
          payload = {
            first_name: values.first_name,
            last_name: values.last_name,
            email: values.email,
            password: values.password,
            confirm_password: values.password,
            target: values.target,
          };
        } else if (role === 'student') {
          payload = {
            first_name: values.first_name,
            last_name: values.last_name,
            phone: values.phone,
            email: values.email,
            password_hash: values.password,
            gender: values.gender,
            date_of_birth: values.date_of_birth,
            lidId: values.lidId,
            eventsId: values.eventsId,
            groupsId: values.groupsId,
          };
        } else {
          payload = {
            first_name: values.first_name,
            last_name: values.last_name,
            email: values.email,
            password_hash: values.password,
          };
        }

        const res = await authService.signUp(payload, role);
        if (res?.status !== 201) throw new Error(res?.data?.message);

        setItem('access_token', res.data.accessToken);
        setItem('role', role);
        navigate(`/login`);
        Notification('success', 'Muvaffaqiyatli', 'Ro‘yxatdan o‘tildi');
      } catch (err) {
        const message =
          err instanceof Error && (err as any).response?.data?.message
            ? (err as any).response.data.message
            : 'Xatolik yuz berdi';
        alert(message);
      } finally {
        setSubmitting(false);
      }
    },
    [role, navigate]
  );

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-100 to-blue-300 p-4">
      <div className="bg-white p-10 rounded-xl shadow-xl max-w-lg w-full">
        <h2 className="text-3xl font-bold text-center text-gray-800 mb-6">Ro‘yxatdan o‘tish</h2>
        <Formik
          initialValues={{
            first_name: '',
            last_name: '',
            name: '',
            email: '',
            password: '',
            confirm_password: '',
            phone: '',
            gender: '',
            date_of_birth: '',
            lidId: 0,
            eventsId: 0,
            groupsId: 0,
            target: '',
            role: '',
          }}
          validationSchema={validationSchema}
          onSubmit={handleSubmit}
        >
          {({ handleSubmit, handleChange, values, isSubmitting }) => (
            <form onSubmit={handleSubmit} className="space-y-4">
              <select
                name="role"
                value={values.role}
                onChange={(e) => {
                  handleChange(e);
                  setRole(e.target.value);
                }}
                className="w-full p-3 border border-gray-300 rounded-lg"
              >
                <option value="">Rolni tanlang</option>
                <option value="teacher">O‘qituvchi</option>
                <option value="student">Talaba</option>
                <option value="admin">Admin</option>
                <option value="lid">Lid</option>
              </select>

              {role === 'lid' && (
                <>
                  <input name="first_name" placeholder="Ism" value={values.first_name} onChange={handleChange} className="w-full p-3 border rounded-lg" />
                  <input name="last_name" placeholder="Familiya" value={values.last_name} onChange={handleChange} className="w-full p-3 border rounded-lg" />
                  <input name="target" placeholder="Target" value={values.target} onChange={handleChange} className="w-full p-3 border rounded-lg" />
                  <input name="email" placeholder="Email" value={values.email} onChange={handleChange} type="email" className="w-full p-3 border rounded-lg" />
                  <input name="password" placeholder="Parol" value={values.password} onChange={handleChange} type="password" className="w-full p-3 border rounded-lg" />
                  <input name="confirm_password" placeholder="Parolni tasdiqlang" value={values.confirm_password} onChange={handleChange} type="password" className="w-full p-3 border rounded-lg" />
                </>
              )}

              {role === 'student' && (
                <>
                  <input name="first_name" placeholder="Ism" value={values.first_name} onChange={handleChange} className="w-full p-3 border rounded-lg" />
                  <input name="last_name" placeholder="Familiya" value={values.last_name} onChange={handleChange} className="w-full p-3 border rounded-lg" />
                  <input name="phone" placeholder="Telefon" value={values.phone} onChange={handleChange} className="w-full p-3 border rounded-lg" />
                  <input name="email" placeholder="Email" value={values.email} onChange={handleChange} type="email" className="w-full p-3 border rounded-lg" />
                  <input name="password" placeholder="Parol" value={values.password} onChange={handleChange} type="password" className="w-full p-3 border rounded-lg" />
                  <input name="gender" placeholder="Jins (male/female)" value={values.gender} onChange={handleChange} className="w-full p-3 border rounded-lg" />
                  <input name="date_of_birth" placeholder="Tug‘ilgan sana" value={values.date_of_birth} onChange={handleChange} className="w-full p-3 border rounded-lg" />
                  <input name="lidId" type="number" placeholder="Lid ID" value={values.lidId} onChange={handleChange} className="w-full p-3 border rounded-lg" />
                  <input name="eventsId" type="number" placeholder="Event ID" value={values.eventsId} onChange={handleChange} className="w-full p-3 border rounded-lg" />
                  <input name="groupsId" type="number" placeholder="Group ID" value={values.groupsId} onChange={handleChange} className="w-full p-3 border rounded-lg" />
                </>
              )}

              {(role === 'teacher' || role === 'admin') && (
                <>
                  <input name="first_name" placeholder="Ism" value={values.first_name} onChange={handleChange} className="w-full p-3 border rounded-lg" />
                  <input name="last_name" placeholder="Familiya" value={values.last_name} onChange={handleChange} className="w-full p-3 border rounded-lg" />
                  <input name="email" placeholder="Email" value={values.email} onChange={handleChange} type="email" className="w-full p-3 border rounded-lg" />
                  <input name="password" placeholder="Parol" value={values.password} onChange={handleChange} type="password" className="w-full p-3 border rounded-lg" />
                </>
              )}

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 disabled:bg-blue-400"
              >
                {isSubmitting ? 'Yuklanmoqda...' : "Ro‘yxatdan o‘tish"}
              </button>
            </form>
          )}
        </Formik>
      </div>
    </div>
  );
};

export default SignUp;
