import { extname } from "path";

const files = [
  "report.docx",
  "notes.txt",
  "data.json",
  "README.md",
  "index.js",
  "todo.txt",
];

const filteredFiles = files.filter((file) => {
  const ext = extname(file);
  return ext === ".txt" || ext === ".md";
});

console.log(filteredFiles);
