import { cpus as _cpus } from "os";

const cpus = _cpus();

console.log("CPU yadrolari soni:", cpus.length);

cpus.forEach((cpu, index) => {
  console.log(
    `Yadro ${index + 1}: Model - ${cpu.model}, Tezlik - ${cpu.speed} MHz`
  );
});
