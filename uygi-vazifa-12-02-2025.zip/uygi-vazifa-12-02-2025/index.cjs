const path = require("path");

const fullPath = path.join("/home/user/", "projects/myapp/", "server.js");

console.log(fullPath);
