const paths = [
  "C://Users//Admin//Desktop//project//..//index.js",
  "/home/user/docs/../images/photo.png",
  "./folder/subfolder/../../script.js",
];

const normalizedPaths = paths.map((p) => path.normalize(p));

normalizedPaths.forEach((p, index) => console.log(`Path ${index + 1}: ${p}`));
