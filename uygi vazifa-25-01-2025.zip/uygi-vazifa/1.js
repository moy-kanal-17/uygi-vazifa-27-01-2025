function findYearsDifference(fatherAge, childAge) {
  let years = 0;
  while (true) {
    if (fatherAge + years === 2 * (childAge + years)) {
      return `${years} yildan keyin`;
    }
    if (fatherAge - years === 2 * (childAge - years)) {
      return `${years} yil avval`;
    }
    years++;
  }
}

console.log(findYearsDifference(40, 10));
