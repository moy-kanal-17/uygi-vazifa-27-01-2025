function select(s1, s2) {
  const uniqueS1 = s1.split("").filter((char) => !s2.includes(char));
  const uniqueS2 = s2.split("").filter((char) => !s1.includes(char));
  return [...new Set(uniqueS1.concat(uniqueS2))].join("");
}
const s1 = "abcd";
const s2 = "cdef";
console.log(select(s1, s2));