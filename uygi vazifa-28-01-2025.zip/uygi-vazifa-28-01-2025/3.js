const countLetters = (str) => {
  const counts = [...str.replace(/\s/g, "")].reduce((acc, char) => {
    acc[char] = (acc[char] || 0) + 1;
    return acc;
  }, {});
  return Object.entries(counts)
    .map(([char, count]) => `${char}${"*".repeat(count)}`)
    .join(", ");
};
const str = "Bu uchinchi vazifa";
console.log(countLetters(str));