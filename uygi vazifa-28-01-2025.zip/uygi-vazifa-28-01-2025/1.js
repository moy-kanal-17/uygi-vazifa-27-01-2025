function truncate(str, maxlength) {
  return str.length > maxlength ? str.slice(0, maxlength) + "…" : str;
}
const str = "Bu birinchi vazifa";
console.log(truncate(str, 10)); // Bu birinch…