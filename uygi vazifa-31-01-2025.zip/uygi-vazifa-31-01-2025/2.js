function getBankWorkDate(workDays) {
  let date = new Date(2024, 0, 1);
  let count = 0;
  while (count < workDays) {
    let dayOfWeek = date.getDay();
    if (dayOfWeek !== 0 && dayOfWeek !== 6) {
      count++;
    }
  if (count < workDays) date.setDate(date.getDate() + 1);
  }

  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(
    2,
    "0"
  )}-${String(date.getDate()).padStart(2, "0")}`;
}
console.log(getBankWorkDate(60));
