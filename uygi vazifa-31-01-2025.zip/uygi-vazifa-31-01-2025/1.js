function calculateWorkingHours(startTime, endTime) {
    const [startHour, startMinute] = startTime.split(":").map(Number);
    const [endHour, endMinute] = endTime.split(":").map(Number);

    if (endHour < startHour || (endHour === startHour && endMinute < startMinute)) {
        return "Xato: tugash vaqti boshlanish vaqtidan oldin bo'lishi mumkin emas";
    }

    let totalMinutes = (endHour * 60 + endMinute) - (startHour * 60 + startMinute);
    let hours = Math.floor(totalMinutes / 60);
    let minutes = totalMinutes % 60;

    return `Ish vaqti: ${hours} soat ${minutes} daqiqa`;
}
console.log(calculateWorkingHours("09:00", "17:30")); 
console.log(calculateWorkingHours("10:00", "09:00")); 