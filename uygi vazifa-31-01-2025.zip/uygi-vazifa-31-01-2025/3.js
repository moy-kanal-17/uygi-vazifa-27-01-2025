function findCommonPairs(obj1, obj2) {
  let result = {};

  function compareObjects(o1, o2, res) {
    for (let key in o1) {
      if (o2.hasOwnProperty(key)) {
        if (typeof o1[key] === "object" && typeof o2[key] === "object") {
          res[key] = {};
          compareObjects(o1[key], o2[key], res[key]);
          if (Object.keys(res[key]).length === 0) delete res[key];
        } else if (o1[key] === o2[key]) {
          res[key] = o1[key];}}}}
compareObjects(obj1, obj2, result);
return result;
}
const jsonData1 = {
  user: {
    name: "Ali",
    age: 25,
    address: {
      city: "Tashkent",
      zip: "100000",
    },
  },
  active: true,
};
const jsonData2 = {
  user: {
    name: "Ali",
    age: 30,
    address: {
      city: "Tashkent",
      zip: "200000",
    },
  },
  active: true,
};
console.log(findCommonPairs(jsonData1, jsonData2));