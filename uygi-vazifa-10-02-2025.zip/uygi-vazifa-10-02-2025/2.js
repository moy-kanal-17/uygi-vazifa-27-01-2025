function sumUntilZero(arr) {
  let sum = 0;
  let countMap = new Map();

  for (let i = arr.length - 1; i >= 0; i--) {
    let num = arr[i];
    if (num === 0) break;

    countMap.set(num, (countMap.get(num) || 0) + 1);
    sum += Math.pow(num, countMap.get(num));
  }

  return sum;
}

console.log(sumUntilZero([3, 2, 3, 4, 0, 5, 2, 3]));
console.log(sumUntilZero([1, 2, 3, 4, 5]));


