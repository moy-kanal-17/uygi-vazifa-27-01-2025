async function getSurahWordFrequency(surahNumber) {
  const apiURL = `https://api.alquran.cloud/v1/surah/${surahNumber}/uz.sodik`;

  try {
    let response = await fetch(apiURL);
    let data = await response.json();
    let text = data.data.ayahs.map((ayat) => ayat.text).join(" ");

    text = text.replace(/[.,!?]/g, "").toLowerCase();
    let words = text.split(/\s+/);

    let wordMap = new Map();
    words.forEach((word) => {
      wordMap.set(word, (wordMap.get(word) || 0) + 1);
    });

    return wordMap;
  } catch (error) {
    console.error("Xatolik yuz berdi:", error);
  }
}

getSurahWordFrequency(1).then((wordMap) => console.log(wordMap));
