const svgNS = "http://www.w3.org/2000/svg";

const svg = document.createElementNS(svgNS, "svg");
svg.setAttribute("width", "400");
svg.setAttribute("height", "400");
document.body.appendChild(svg);

const head = document.createElementNS(svgNS, "circle");
head.setAttribute("cx", "200");
head.setAttribute("cy", "200");
head.setAttribute("r", "100");
head.setAttribute("fill", "#90A4AE");
svg.appendChild(head);

const leftEar = document.createElementNS(svgNS, "circle");
leftEar.setAttribute("cx", "100");
leftEar.setAttribute("cy", "150");
leftEar.setAttribute("r", "50");
leftEar.setAttribute("fill", "#90A4AE");

const leftEarr = document.createElementNS(svgNS, "circle");
leftEarr.setAttribute("cx", "100");
leftEarr.setAttribute("cy", "150");
leftEarr.setAttribute("r", "30");
leftEarr.setAttribute("fill", "black");

svg.appendChild(leftEar);
svg.appendChild(leftEarr);

const rightEar = document.createElementNS(svgNS, "circle");
rightEar.setAttribute("cx", "300");
rightEar.setAttribute("cy", "150");
rightEar.setAttribute("r", "50");
rightEar.setAttribute("fill", "#90A4AE");

const rightEarr = document.createElementNS(svgNS, "circle");
rightEarr.setAttribute("cx", "300");
rightEarr.setAttribute("cy", "150");
rightEarr.setAttribute("r", "30");
rightEarr.setAttribute("fill", "black");

svg.appendChild(rightEar);
svg.appendChild(rightEarr);

const leftEye = document.createElementNS(svgNS, "circle");
leftEye.setAttribute("cx", "170");
leftEye.setAttribute("cy", "190");
leftEye.setAttribute("r", "20");
leftEye.setAttribute("fill", "white");
svg.appendChild(leftEye);

const rightEye = document.createElementNS(svgNS, "circle");
rightEye.setAttribute("cx", "230");
rightEye.setAttribute("cy", "190");
rightEye.setAttribute("r", "20");
rightEye.setAttribute("fill", "white");
svg.appendChild(rightEye);

const leftPupil = document.createElementNS(svgNS, "circle");
leftPupil.setAttribute("cx", "175");
leftPupil.setAttribute("cy", "190");
leftPupil.setAttribute("r", "7");
leftPupil.setAttribute("fill", "black");
svg.appendChild(leftPupil);

const rightPupil = document.createElementNS(svgNS, "circle");
rightPupil.setAttribute("cx", "225");
rightPupil.setAttribute("cy", "190");
rightPupil.setAttribute("r", "7");
rightPupil.setAttribute("fill", "black");
svg.appendChild(rightPupil);

const nose = document.createElementNS(svgNS, "ellipse");
nose.setAttribute("cx", "200");
nose.setAttribute("cy", "230");
nose.setAttribute("rx", "20");
nose.setAttribute("ry", "35");
nose.setAttribute("fill", "#A67C52");
svg.appendChild(nose);
