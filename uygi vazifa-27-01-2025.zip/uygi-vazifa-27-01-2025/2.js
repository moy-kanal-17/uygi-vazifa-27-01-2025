const doira = {
  radius: null,
  calculateArea() {
    if (this.radius === null) {
      return "Radius kiritilmagan!";
    }
    return Math.PI * this.radius ** 2;
  },
};
doira.radius = parseFloat(prompt("Doiraning radiusini kiriting:"));
console.log(`Doiraning radiusi: ${doira.radius}`);
console.log(`Doiraning yuzi: ${doira.calculateArea().toFixed(2)}`);
