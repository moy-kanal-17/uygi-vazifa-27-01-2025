const product = {
  name: "Telefon",
  quantity: 10,
  price: 300,
  productInfo() {
    return `Mahsulot nomi: ${this.name}, Miqdori: ${this.quantity}, Narxi: ${this.price} USD`;
  },
  setPrice(newPrice) {
    this.price = newPrice;
  },
};
const tovar = { ...product };
tovar.setPrice(250);
console.log("Product haqida:", product.productInfo());
console.log("Tovar haqida:", tovar.productInfo());
