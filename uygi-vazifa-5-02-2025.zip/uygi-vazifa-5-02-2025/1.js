async function getUsers(names) {
  let requests = names.map((name) =>
    fetch(`https://api.github.com/users/${name}`)
      .then((response) => (response.ok ? response.json() : null))
      .catch(() => null)
  );

  return Promise.all(requests);
}
getUsers(["octocat", "torvalds", "nonexistentuser"]).then(console.log);