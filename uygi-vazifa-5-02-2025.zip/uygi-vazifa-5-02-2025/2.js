async function getUserPosts(userId) {
  try {
    let [userRes, postsRes] = await Promise.all([
      fetch(`https://jsonplaceholder.typicode.com/users/${userId}`),
      fetch(`https://jsonplaceholder.typicode.com/posts?userId=${userId}`),
    ]);

    if (!userRes.ok || !postsRes.ok) throw new Error("Ma'lumot topilmadi");

    let user = await userRes.json();
    let posts = await postsRes.json();

    console.log(`Avtor: ${user.name}`);
    console.log(`Shahar: ${user.address.city}`);
    console.log(`Kompaniya: ${user.company.name}`);
    console.log("Maqolalar:");
    posts.forEach((post) => console.log(`- ${post.title}`));
  } catch (error) {
    console.error("Xatolik:", error.message);
  }
}
getUserPosts(1);