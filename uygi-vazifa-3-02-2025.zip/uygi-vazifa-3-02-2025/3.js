class University {
  constructor(name) {
    this.name = name;
    this.departments = [];
  }

  addDepartment(department) {
    this.departments.push(department);
  }

  removeDepartment(department) {
    this.departments = this.departments.filter((dep) => dep !== department);
  }

  showDepartments() {
    console.log(this.departments);
  }
}

let uni = new University("National University");
uni.addDepartment("Computer Science");
uni.addDepartment("Mathematics");
uni.addDepartment("Physics");
uni.addDepartment("Biology");
uni.addDepartment("Chemistry");

uni.removeDepartment("Mathematics");
uni.removeDepartment("Biology");

uni.showDepartments();
