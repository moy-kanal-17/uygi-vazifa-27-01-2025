class Product {
  static productCount = 0;
  constructor(id, name, price) {
    this.id = id;
    this.name = name;
    this.price = price;
    Product.productCount++;
  }

  totalPrice() {
    return this.price;
  }
}

class CareProduct extends Product {
  constructor(id, name, price, warrantyPeriod) {
    super(id, name, price);
    this.warrantyPeriod = warrantyPeriod;
  }

  totalPrice() {
    let discount = 0;
    if (this.warrantyPeriod <= 5 && this.warrantyPeriod > 0) {
      discount = (6 - this.warrantyPeriod) * 0.1;
    }
    return this.price * (1 - discount);
  }
}

